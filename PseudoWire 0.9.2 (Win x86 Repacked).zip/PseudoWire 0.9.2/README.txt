      Pseudo Wire
Written by Nathan cousins
       (c)  2012


SFML	- http://www.sfml-dev.org/
Lua	- http://www.lua.org/
TinyXML	- http://sourceforge.net/projects/tinyxml/


Pseudo Wire is a scriptable logic simulator designed as a
recreation of Wiremod (an addon for Garry's Mod) in a
standalone environment.

Create logical machines using Lua. Spawn parts and
components, wire them together, and interact with them.

Pseudo Wire is designed so that anyone who has used Wiremod
before would be able to pick up how to play in almost no
time at all. Any newcomers shouldn't take too long get the
hang of how the game plays, feels and works.


IMPORTANT:

I am not responsible any inconveniences or harm caused by
third-party Pseudo Wire addons.

Only download Pseudo Wire addons from developers you trust.
